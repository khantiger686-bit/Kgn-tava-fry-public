KGN TAVA FRY WEBSITE STARTER

Files:
- index.html: responsive restaurant website with category filters, working demo cart, WhatsApp order checkout, WhatsApp table-booking request, contact and map links.
- assets/: food imagery used by the page.

HOW TO PREVIEW
Open index.html in a browser.

HOW TO PUBLISH
Upload index.html and the entire assets folder to a static website host (for example GitHub Pages, Netlify, or your hosting provider). Keep the assets folder beside index.html.

IMPORTANT
- WhatsApp ordering sends the cart as a message to 7016742863. It does not charge payments or create a confirmed order automatically.
- Table booking is a WhatsApp request and needs restaurant confirmation.
- The waiter/billing app integration section is a placeholder for the next integration step; it is not connected to a live POS database yet.
- Prices are starter examples based on the design mockup. Replace them with your real menu before publishing.
- Address shown: Raopura Nawab Wada, Machipith Main Bazar, Vadodara, Gujarat; verify the city/address details before going live.
- No GST is displayed or added in this demo.
