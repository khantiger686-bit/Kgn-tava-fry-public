KGN TAVA FRY - Android Studio Project

APP:
- KGN TAVA FRY
- 6 tables
- Full menu from supplied 4-page menu
- Waiter ordering
- KOT
- Kitchen workflow
- Bills
- Print Bill
- Paid
- Daily reports
- Backup
- No GST
- No login
- Offline local storage

BUILD APK:
1. Install Android Studio on Windows/Mac/Linux.
2. Open this folder: KGN_TAVA_FRY_ANDROID_PROJECT
3. Let Android Studio download the Android Gradle Plugin/SDK if prompted.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK will be generated under:
   app/build/outputs/apk/debug/app-debug.apk

For a release APK, use Build > Generate Signed App Bundle / APK.

NOTE:
This chat environment does not have the Android SDK/Gradle build environment, so the APK itself is not compiled here. This is the Android Studio source project ready for compilation.
