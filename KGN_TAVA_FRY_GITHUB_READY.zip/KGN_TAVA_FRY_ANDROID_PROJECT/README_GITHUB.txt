KGN TAVA FRY - GitHub APK Build

1. GitHub par New repository banao (example: kgn-tava-fry-app).
2. Is project ke saare files repository ke root me upload karo.
3. Branch ka naam main rakho (ya workflow me master bhi supported hai).
4. GitHub -> Actions kholo.
5. "Build KGN TAVA FRY APK" workflow select karo.
6. "Run workflow" dabao.
7. Build complete hone ke baad workflow ke run page par Artifacts me "KGN-TAVA-FRY-APK" milega.
8. ZIP artifact download karke app-debug.apk nikalo aur Android phone me install karo.

Note: App KGN TAVA FRY ke liye configured hai: 6 tables, no GST, no login, offline/local use.
